package tw.carmusic.yt.player

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

interface YouTubePlayerCallback {
    fun onVideoStarted(videoId: String, title: String)
    fun onStateChanged(isPlaying: Boolean, isBuffering: Boolean)
    fun onVideoEnded()
}

/**
 * v1.2 根本性修正：
 * 改為直接載入 https://m.youtube.com/watch?v={videoId} 並注入輕量 HTML5 <video> 監聽腳本：
 * 1. 徹底避開 YouTube iframe_api 在車機 WebView 卡死轉圈及官方 MV 禁止嵌入（Error 150/153）的問題！
 * 2. 自動隱藏行動版多餘介面，僅保留乾淨播放器畫面。
 * 3. 直接監聽原生 <video> 的 playing / pause / ended 事件，播完立刻無縫切下一首不重複歌曲。
 */
@SuppressLint("SetJavaScriptEnabled")
class YouTubeCarPlayerView(
    context: Context,
    private val callback: YouTubePlayerCallback
) : WebView(context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentVideoId: String = ""
    private var endedDispatchedForId: String = ""

    init {
        setBackgroundColor(Color.BLACK)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString =
                "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        }

        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                // 攔截外部 intent:// 避免跳出 App 打開系統 YouTube
                return !url.startsWith("http://") && !url.startsWith("https://")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != null && url.contains("youtube.com/watch")) {
                    injectVideoController()
                }
            }
        }

        addJavascriptInterface(JsBridge(), "AndroidBridge")
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        // 切背景開導航時維持可見狀態，不讓 WebView 自動暫停音訊
        super.onWindowVisibilityChanged(View.VISIBLE)
    }

    fun playVideoById(videoId: String) {
        currentVideoId = videoId
        endedDispatchedForId = ""
        mainHandler.post {
            loadUrl("https://m.youtube.com/watch?v=$videoId")
        }
    }

    fun play() {
        mainHandler.post {
            evaluateJavascript(
                "(function(){var v=document.querySelector('video'); if(v){v.muted=false; v.play();}})();",
                null
            )
        }
    }

    fun pause() {
        mainHandler.post {
            evaluateJavascript(
                "(function(){var v=document.querySelector('video'); if(v){v.pause();}})();",
                null
            )
        }
    }

    private fun injectVideoController() {
        val vid = currentVideoId.replace("'", "")
        val js = """
            (function() {
              if (!document.getElementById('car_music_css')) {
                var style = document.createElement('style');
                style.id = 'car_music_css';
                style.innerHTML = 'ytm-mobile-topbar-renderer, .related-chips-slot-wrapper, ytm-item-section-renderer, ytm-single-column-watch-next-results-renderer > :not(:first-child) { display: none !important; } body { background: #000 !important; overflow: hidden !important; }';
                document.head.appendChild(style);
              }
              function hookVideo() {
                var v = document.querySelector('video');
                if (!v) { setTimeout(hookVideo, 400); return; }
                if (v.dataset.carHooked === '$vid') return;
                v.dataset.carHooked = '$vid';
                v.muted = false;
                v.play().catch(function(){});

                var titleEl = document.querySelector('h2.slim-video-information-title, .slim-video-metadata-header h2');
                var cleanTitle = (titleEl ? titleEl.innerText : document.title).replace(' - YouTube', '').trim();

                v.addEventListener('playing', function() {
                  AndroidBridge.onPlaying('$vid', cleanTitle);
                });
                v.addEventListener('pause', function() {
                  if (!v.ended) AndroidBridge.onPaused();
                });
                v.addEventListener('ended', function() {
                  AndroidBridge.onEnded('$vid');
                });
                if (!v.paused && !v.ended) {
                  AndroidBridge.onPlaying('$vid', cleanTitle);
                }
              }
              hookVideo();
            })();
        """.trimIndent()
        evaluateJavascript(js, null)
    }

    private inner class JsBridge {
        @JavascriptInterface
        fun onPlaying(videoId: String, title: String) {
            mainHandler.post {
                callback.onVideoStarted(videoId, title)
            }
        }

        @JavascriptInterface
        fun onPaused() {
            mainHandler.post {
                callback.onStateChanged(isPlaying = false, isBuffering = false)
            }
        }

        @JavascriptInterface
        fun onEnded(videoId: String) {
            mainHandler.post {
                if (endedDispatchedForId != videoId) {
                    endedDispatchedForId = videoId
                    callback.onVideoEnded()
                }
            }
        }
    }
}
