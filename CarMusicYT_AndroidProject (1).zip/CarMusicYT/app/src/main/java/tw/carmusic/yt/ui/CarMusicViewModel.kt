package tw.carmusic.yt.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import tw.carmusic.yt.data.MusicRepository
import tw.carmusic.yt.data.YouTubePlaylistFetcher
import tw.carmusic.yt.model.MusicGenre
import tw.carmusic.yt.model.YouTubeTrack
import tw.carmusic.yt.player.YouTubeCarPlayerView
import tw.carmusic.yt.player.YouTubePlayerCallback
import tw.carmusic.yt.service.CarMediaBridge
import tw.carmusic.yt.service.MusicKeepAliveService

data class CarMusicUiState(
    val genres: List<MusicGenre> = emptyList(),
    val activeGenre: MusicGenre? = null,
    val currentTitle: String = "",
    val currentVideoId: String = "",
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val remainingUnplayed: Int = 0,
    val totalInPlaylist: Int = 0,
    val statusHint: String = "點選任一音樂類型，立即連續不重複播放",
    val showVideoPreview: Boolean = true
)

class CarMusicViewModel(application: Application) : AndroidViewModel(application), YouTubePlayerCallback {

    private val repository = MusicRepository(application)
    private val _uiState = MutableStateFlow(
        CarMusicUiState(
            genres = repository.getAllGenres(),
            showVideoPreview = repository.isShowVideoPreview()
        )
    )
    val uiState: StateFlow<CarMusicUiState> = _uiState.asStateFlow()

    private var playerView: YouTubeCarPlayerView? = null
    private var fetchJob: Job? = null

    private var currentPool: List<YouTubeTrack> = emptyList()
    private var unplayedQueue: ArrayDeque<YouTubeTrack> = ArrayDeque()
    private val sessionHistory = ArrayList<YouTubeTrack>()
    private var historyCursor = -1

    init {
        CarMediaBridge.onPlayPause = { togglePlayPause() }
        CarMediaBridge.onNext = { playNextUnplayed() }
        CarMediaBridge.onPrevious = { playPreviousInHistory() }
    }

    fun attachPlayer(view: YouTubeCarPlayerView) {
        playerView = view
    }

    fun selectGenre(genre: MusicGenre) {
        fetchJob?.cancel()
        repository.saveLastGenreId(genre.id)
        currentPool = emptyList()
        unplayedQueue.clear()
        sessionHistory.clear()
        historyCursor = -1

        _uiState.update {
            it.copy(
                activeGenre = genre,
                isBuffering = true,
                isPlaying = false,
                currentTitle = "載入「${genre.title}」歌單中…",
                statusHint = "正在讀取 YouTube 歌單曲目…"
            )
        }

        fetchJob = viewModelScope.launch {
            val result = YouTubePlaylistFetcher.fetchTracks(genre.playlistId)
            result.onSuccess { tracks ->
                currentPool = tracks
                buildNonRepeatingQueue(genre.id, tracks)
                playNextUnplayed()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isBuffering = false,
                        isPlaying = false,
                        currentTitle = "無法載入「${genre.title}」歌單",
                        statusHint = "讀取失敗（${err.message ?: "請檢查車機網路"}）"
                    )
                }
            }
        }
    }

    private fun buildNonRepeatingQueue(genreId: String, pool: List<YouTubeTrack>) {
        val alreadyPlayed = repository.getPlayedIds(genreId)
        var candidates = pool.filterNot { it.videoId in alreadyPlayed }
        if (candidates.isEmpty()) {
            repository.clearPlayedHistory(genreId)
            candidates = pool
        }
        unplayedQueue = ArrayDeque(candidates.shuffled())
    }

    fun playNextUnplayed() {
        val genre = _uiState.value.activeGenre ?: return
        if (historyCursor in 0 until sessionHistory.lastIndex) {
            historyCursor++
            playTrack(sessionHistory[historyCursor])
            return
        }

        if (unplayedQueue.isEmpty() && currentPool.isNotEmpty()) {
            repository.clearPlayedHistory(genre.id)
            unplayedQueue = ArrayDeque(currentPool.shuffled())
        }

        val nextTrack = unplayedQueue.removeFirstOrNull() ?: return
        repository.markVideoPlayed(genre.id, nextTrack.videoId)
        sessionHistory.add(nextTrack)
        historyCursor = sessionHistory.lastIndex
        playTrack(nextTrack)
    }

    fun playPreviousInHistory() {
        if (historyCursor > 0) {
            historyCursor--
            playTrack(sessionHistory[historyCursor])
        } else {
            playNextUnplayed()
        }
    }

    private fun playTrack(track: YouTubeTrack) {
        _uiState.update {
            it.copy(
                currentVideoId = track.videoId,
                currentTitle = track.title.ifBlank { "載入歌曲中…" },
                isBuffering = true,
                remainingUnplayed = unplayedQueue.size,
                totalInPlaylist = currentPool.size,
                statusHint = "已載入 ${currentPool.size} 首 · 開啟播放中…"
            )
        }
        playerView?.playVideoById(track.videoId)
    }

    fun togglePlayPause() {
        val state = _uiState.value
        if (state.activeGenre == null) {
            state.genres.firstOrNull()?.let { selectGenre(it) }
            return
        }
        if (state.isPlaying) {
            playerView?.pause()
        } else {
            playerView?.play()
        }
    }

    fun toggleVideoPreview() {
        val next = !_uiState.value.showVideoPreview
        repository.setShowVideoPreview(next)
        _uiState.update { it.copy(showVideoPreview = next) }
    }

    fun resetActiveGenreHistory() {
        val genre = _uiState.value.activeGenre ?: return
        repository.clearPlayedHistory(genre.id)
        if (currentPool.isNotEmpty()) {
            unplayedQueue = ArrayDeque(currentPool.shuffled())
        }
        _uiState.update {
            it.copy(
                remainingUnplayed = unplayedQueue.size,
                statusHint = "已重置「${genre.title}」已播紀錄並重新洗牌"
            )
        }
    }

    fun addCustomPlaylist(title: String, rawUrlOrId: String): Boolean {
        val added = repository.addCustomPlaylist(title, rawUrlOrId) ?: return false
        _uiState.update {
            it.copy(
                genres = repository.getAllGenres(),
                statusHint = "已新增自訂歌單：${added.title}"
            )
        }
        selectGenre(added)
        return true
    }

    fun removeCustomPlaylist(genreId: String) {
        repository.removeCustomPlaylist(genreId)
        _uiState.update {
            it.copy(
                genres = repository.getAllGenres(),
                statusHint = "已刪除自訂歌單"
            )
        }
    }

    override fun onVideoStarted(videoId: String, title: String) {
        val cleanTitle = title.ifBlank { _uiState.value.currentTitle.ifBlank { "YouTube 音樂播放中" } }
        val genreTitle = _uiState.value.activeGenre?.title ?: "YouTube 音樂"
        _uiState.update {
            it.copy(
                currentVideoId = videoId,
                currentTitle = cleanTitle,
                isPlaying = true,
                isBuffering = false,
                remainingUnplayed = unplayedQueue.size,
                totalInPlaylist = currentPool.size,
                statusHint = "不重複連續播放中 · 剩餘未播 ${unplayedQueue.size} / ${currentPool.size} 首"
            )
        }
        MusicKeepAliveService.updateState(getApplication(), cleanTitle, genreTitle, true)
    }

    override fun onStateChanged(isPlaying: Boolean, isBuffering: Boolean) {
        _uiState.update { it.copy(isPlaying = isPlaying, isBuffering = isBuffering) }
        val state = _uiState.value
        if (state.activeGenre != null) {
            MusicKeepAliveService.updateState(
                getApplication(),
                state.currentTitle.ifBlank { state.activeGenre.title },
                state.activeGenre.title,
                isPlaying
            )
        }
    }

    override fun onVideoEnded() {
        playNextUnplayed()
    }
}
