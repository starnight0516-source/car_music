package tw.carmusic.yt.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import tw.carmusic.yt.model.YouTubeTrack
import java.net.HttpURLConnection
import java.net.URL

object YouTubePlaylistFetcher {

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    suspend fun fetchTracks(playlistId: String): Result<List<YouTubeTrack>> = withContext(Dispatchers.IO) {
        runCatching {
            val fromPage = runCatching { fetchFromPlaylistHtml(playlistId) }.getOrDefault(emptyList())
            if (fromPage.isNotEmpty()) return@runCatching fromPage

            val fromRss = runCatching { fetchFromAtomFeed(playlistId) }.getOrDefault(emptyList())
            if (fromRss.isNotEmpty()) return@runCatching fromRss

            throw IllegalStateException("無法取得歌單曲目，請確認網路連線或更換歌單")
        }
    }

    private fun fetchFromPlaylistHtml(playlistId: String): List<YouTubeTrack> {
        val html = httpGet("https://www.youtube.com/playlist?list=$playlistId&hl=zh-TW")
        val seen = LinkedHashSet<String>()
        val tracks = mutableListOf<YouTubeTrack>()

        val rendererRegex = Regex(
            "\"playlistVideoRenderer\":\{\"videoId\":\"([a-zA-Z0-9_-]{11})\".*?\"title\":\{\"runs\":\[\{\"text\":\"([^\"]+)\"",
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        for (m in rendererRegex.findAll(html)) {
            val vid = m.groupValues[1]
            val title = unescapeJsonString(m.groupValues[2])
            if (seen.add(vid)) {
                tracks.add(YouTubeTrack(videoId = vid, title = title))
            }
        }

        if (tracks.isEmpty()) {
            val idRegex = Regex("\"videoId\":\"([a-zA-Z0-9_-]{11})\"")
            for (m in idRegex.findAll(html)) {
                val vid = m.groupValues[1]
                if (seen.add(vid)) {
                    tracks.add(YouTubeTrack(videoId = vid, title = ""))
                }
            }
        }
        return tracks
    }

    private fun fetchFromAtomFeed(playlistId: String): List<YouTubeTrack> {
        val xml = httpGet("https://www.youtube.com/feeds/videos.xml?playlist_id=$playlistId")
        val seen = LinkedHashSet<String>()
        val tracks = mutableListOf<YouTubeTrack>()
        val entryRegex = Regex("<entry>(.*?)</entry>", setOf(RegexOption.DOT_MATCHES_ALL))
        val idRegex = Regex("<yt:videoId>([a-zA-Z0-9_-]{11})</yt:videoId>")
        val titleRegex = Regex("<title>(.*?)</title>")

        for (entry in entryRegex.findAll(xml)) {
            val block = entry.groupValues[1]
            val vid = idRegex.find(block)?.groupValues?.get(1) ?: continue
            val title = titleRegex.find(block)?.groupValues?.get(1)?.let { decodeXmlEntities(it) }.orEmpty()
            if (seen.add(vid)) {
                tracks.add(YouTubeTrack(videoId = vid, title = title))
            }
        }
        return tracks
    }

    private fun httpGet(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 10_000
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept-Language", "zh-TW,zh;q=0.9,en;q=0.8")
        }
        return try {
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode}")
            }
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun unescapeJsonString(raw: String): String =
        raw.replace("\\u0026", "&")
            .replace("\\\"", """)
            .replace("\\\\", "\\")

    private fun decodeXmlEntities(raw: String): String =
        raw.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", """)
            .replace("&#39;", "'")
}
